import platform

separator = '\\' if platform.system() == 'Windows' else '/'